You'd put Forge and LiteLoader installers here.

i.e. forge-1.7.10-10.13.0.1208-installer.jar

It should NOT be the Windows version of the installer.

Any installer will work that has a supported "install_profile.json" in its .jar.